# bot0

bot0 is a modular discord bot  - meaning all features can be disabled/enabled with a click off button through the dashboard ui alongside this you can build custom plugins/mods for the bot. *This is a self-hosted bot* which means you need to host it yourself.

[Installation]() is easy but still requires bit of knowledge about discord bots

**By default this bot only has**

> Slash commands
> Dashboard UI
> Discord Oauth2

Any other [plugin](#plugins) you want in the bot can be installed from our [marketplace](https://market.bot0.app) for free.

# Plugins

As bot0 is fully modular you can install 3rd party plugins for free or just build your own!

# Join our discord
bot0 is a maintained product supported by us, to support it join our [community](https://discord.gg/vc5FZ3sfBX). Here you can find more plugins or support.

# License
Released under [MIT License](LICENSE)

bot0 can be distrubted or modified without any restrictions.

*bot0 by Chle*

